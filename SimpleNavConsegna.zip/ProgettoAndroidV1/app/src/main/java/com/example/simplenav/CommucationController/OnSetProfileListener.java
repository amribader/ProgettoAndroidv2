package com.example.simplenav.CommucationController;

public interface OnSetProfileListener {
    void onSetProfile(Void body);
}
