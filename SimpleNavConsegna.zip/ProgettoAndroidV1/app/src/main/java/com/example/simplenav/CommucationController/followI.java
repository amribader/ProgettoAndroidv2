package com.example.simplenav.CommucationController;

public interface followI {
    void follow(Void body);
}
