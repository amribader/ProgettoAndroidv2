package com.example.simplenav.CommucationController;

public interface getProfile {

    void onGetProfile(getProfileO body);
}
