package com.example.simplenav.DB.PictureDB;

public interface ErrorPictureDBListener {
    void onError(Throwable t);
}
