package com.example.simplenav.CommucationController;

public interface getPictureI {
    void getPicture(GetPicture body);
}
