package com.example.simplenav.ui.Home;

import androidx.lifecycle.ViewModel;

public class HomeBoardViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}