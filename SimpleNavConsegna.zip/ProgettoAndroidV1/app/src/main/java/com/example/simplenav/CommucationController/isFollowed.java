package com.example.simplenav.CommucationController;

public interface isFollowed {
    void isFollowed(follow body);
}
