package com.example.simplenav.CommucationController;

public interface LikeI {
    void like(Void body);
}
