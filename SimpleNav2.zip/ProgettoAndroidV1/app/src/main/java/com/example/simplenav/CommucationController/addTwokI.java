package com.example.simplenav.CommucationController;

import retrofit2.Response;

public interface addTwokI {
    void addTwok(Response<Void> response);
}
