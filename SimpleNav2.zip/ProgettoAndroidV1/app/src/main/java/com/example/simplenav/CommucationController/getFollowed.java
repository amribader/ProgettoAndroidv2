package com.example.simplenav.CommucationController;

import java.util.List;

public interface getFollowed {

    void getFollow(List<getProfileO> body);
}
