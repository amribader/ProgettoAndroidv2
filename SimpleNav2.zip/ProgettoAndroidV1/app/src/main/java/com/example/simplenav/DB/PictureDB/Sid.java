package com.example.simplenav.DB.PictureDB;

public class Sid {

    private String sid;

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getSid() {
        return sid;
    }
}
