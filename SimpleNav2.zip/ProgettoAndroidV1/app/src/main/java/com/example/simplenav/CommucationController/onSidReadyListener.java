package com.example.simplenav.CommucationController;

import com.example.simplenav.DB.PictureDB.Sid;

public interface onSidReadyListener {
    void onSidReasy(Sid body);
}
