package com.example.simplenav.DB.PictureDB;

public interface PictureDBListener {

    void onPictureReady(String picture);

}
